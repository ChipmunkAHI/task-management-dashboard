This is a task management dashboard meant to help users manage their daily tasks.
Currently the frontend is incomplete, as a result users can only add tasks and 
delete them.

It is best to run this code in visual studios, before starting ensure that you
have Vite downloaded, as well as a corresponding npm version. one installed use
the commands "npm install", "npm install @reduxjs/toolkit react-redux", 
"npm install react-hook-form", "npm install -D tailwindcss postcss autoprefixer",
"npx tailwindcss init -p", "npx shadcn-ui@latest init", "npx shadcn-ui@latest add
 button", "npm install lucide-react", "npm install react-router-dom", 
"npm install -D @types/react @types/react-dom", and "npm run dev" in the terminal.


During the creation of this dashboard I made a local storage for which users could
store tasks, ultimately this isn't necessary, the reason behind this was to get a 
visual on if the code was working since the MockApi used could not be directly 
changed.
